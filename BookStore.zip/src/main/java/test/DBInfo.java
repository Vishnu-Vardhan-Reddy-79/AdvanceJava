package test;
public interface DBInfo 
{
   public static final String dbUrl="jdbc:mysql://localhost:3306/sample";
   public static final String uName="root";
   public static final String pWord="vardhan@123";
   
}

